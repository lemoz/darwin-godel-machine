"""
Edit tool implementation for file manipulation.

This tool allows the DGM agent to read, write, and modify files.
"""

import ast
import json
import os
import shlex
import shutil
import tempfile
import time
from pathlib import Path
from typing import Dict, Any, List
from .base_tool import BaseTool, ToolResult, ToolExecutionStatus, ToolParameter


_EDIT_TOOL_RUNNER = r"""
import asyncio
import importlib.util
import json
import sys
import types
from pathlib import Path


def load_edit_tool():
    code_root = Path("/home/dgm_agent/agent_code")
    agent_pkg = types.ModuleType("agent")
    agent_pkg.__path__ = [str(code_root / "agent")]
    sys.modules.setdefault("agent", agent_pkg)

    tools_pkg = types.ModuleType("agent.tools")
    tools_pkg.__path__ = [str(code_root / "agent" / "tools")]
    sys.modules.setdefault("agent.tools", tools_pkg)

    spec = importlib.util.spec_from_file_location(
        "agent.tools.edit_tool",
        code_root / "agent" / "tools" / "edit_tool.py",
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.EditTool


async def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: edit_tool_runner.py PARAMS_JSON")

    params_file = Path(sys.argv[1]).resolve()
    parameters = json.loads(params_file.read_text(encoding="utf-8"))
    edit_tool = load_edit_tool()(working_directory=str(Path.cwd()))
    result = await edit_tool._execute_direct(parameters)
    print(json.dumps({
        "status": result.status.value,
        "output": result.output,
        "error": result.error or "",
    }))


if __name__ == "__main__":
    asyncio.run(main())
"""


def _resolve_and_check(
    file_path_str: str, working_directory: str
) -> "tuple[Path, ToolResult | None]":
    """
    Resolve *file_path_str* relative to *working_directory* and verify that the
    result is contained within it (path-traversal guard).

    Returns ``(resolved_path, None)`` on success, or
    ``(Path('.'), ToolResult(error=...))`` when the path escapes the sandbox.
    """
    wd = Path(working_directory).resolve()
    full = (wd / file_path_str).resolve()

    # Python 3.9+: Path.is_relative_to; fall back to os.path.commonpath for 3.8.
    try:
        contained = full.is_relative_to(wd)
    except AttributeError:  # pragma: no cover — Python < 3.9
        try:
            contained = os.path.commonpath([str(full), str(wd)]) == str(wd)
        except ValueError:
            contained = False

    if not contained:
        return Path("."), ToolResult(
            status=ToolExecutionStatus.ERROR,
            output="",
            error=(
                f"Path escape detected: '{file_path_str}' resolves outside the "
                f"working directory '{wd}'"
            ),
        )
    return full, None


class EditTool(BaseTool):
    """
    Tool for editing files and manipulating code.
    
    This is a placeholder implementation for Phase 1. Full functionality
    will be implemented in a later phase of the MVP development.
    """
    
    def __init__(
        self,
        working_directory: str = None,
        sandbox_manager: Any = None,
        use_sandbox: bool = False,
        timeout: int = 30,
    ):
        """
        Initialize the Edit tool.
        
        Args:
            working_directory: Directory to operate in
            sandbox_manager: Optional Docker sandbox manager for file operations
            use_sandbox: Whether to execute edits through the sandbox when available
            timeout: Default timeout for sandboxed edit operations
        """
        self.working_directory = working_directory
        self.sandbox_manager = sandbox_manager
        self.use_sandbox = use_sandbox
        self.default_timeout = timeout
        super().__init__()

    def _can_use_sandbox(self) -> bool:
        """Return True when sandboxed edit execution is configured."""
        if not self.use_sandbox or self.sandbox_manager is None:
            return False
        readiness_check = getattr(self.sandbox_manager, "is_sandbox_ready", None)
        if readiness_check is not None:
            return bool(readiness_check())
        availability_check = getattr(self.sandbox_manager, "is_docker_available", None)
        if availability_check is None:
            return True
        if not bool(availability_check()):
            return False
        ensure_image = getattr(self.sandbox_manager, "ensure_sandbox_image", None)
        if ensure_image is not None:
            try:
                ensure_image()
            except Exception:
                return False
        return True
    
    def get_name(self) -> str:
        """Get the name of this tool."""
        return "edit"
    
    def get_description(self) -> str:
        """Get a description of what this tool does."""
        return ("Edit and manipulate files. Can read file contents, write new files, "
                "and modify existing files. This is a placeholder implementation.")
    
    def get_parameters(self) -> List[ToolParameter]:
        """Get the parameters this tool accepts."""
        return [
            ToolParameter(
                name="action",
                type="string",
                description=(
                    "Action to perform: 'read', 'write', 'append', "
                    "'modify', 'line_replace', or 'delete'"
                ),
                required=True,
                enum_values=[
                    "read",
                    "write",
                    "append",
                    "modify",
                    "line_replace",
                    "delete",
                ],
            ),
            ToolParameter(
                name="file_path",
                type="string",
                description="Path to the file to edit",
                required=True
            ),
            ToolParameter(
                name="content",
                type="string",
                description=(
                    "Content to write. Required for write/append/line_replace actions; "
                    "use an explicit empty string only to create an empty file."
                ),
                required=False
            ),
            ToolParameter(
                name="content_lines",
                type="array",
                description=(
                    "Alternative to content for write/append/line_replace actions. "
                    "Provide one source line per string; the tool joins lines with "
                    "newlines and adds a final newline when the list is non-empty. "
                    "Use this when large escaped string arguments are unreliable."
                ),
                required=False
            ),
            ToolParameter(
                name="line_number",
                type="integer",
                description=(
                    "1-based start line for read/line_replace actions. Read returns "
                    "numbered context; prefer line_replace over modify when exact "
                    "search_text is unreliable."
                ),
                required=False
            ),
            ToolParameter(
                name="line_count",
                type="integer",
                description=(
                    "Number of existing lines to read or replace for line_replace "
                    "actions. Defaults to 80 for ranged reads and 1 for line_replace."
                ),
                required=False
            ),
            ToolParameter(
                name="search_text",
                type="string",
                description="Text to search for in modify actions",
                required=False
            ),
            ToolParameter(
                name="replace_text",
                type="string",
                description=(
                    "Text to replace with in modify actions. Required for modify; "
                    "use an explicit empty string only for intentional deletion."
                ),
                required=False
            )
        ]

    def validate_parameters(self, parameters: Dict[str, Any]) -> ToolResult:
        """Normalize recoverable edit payload shapes before schema checks."""
        normalization_error = self._normalize_content_arguments(parameters)
        if normalization_error is not None:
            return normalization_error
        return super().validate_parameters(parameters)
    
    async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
        """
        Execute the edit operation.

        All file paths are resolved relative to the working directory and
        checked for containment to prevent path-traversal attacks.

        Args:
            parameters: Dictionary containing edit parameters

        Returns:
            ToolResult: Result of the edit operation
        """
        action = parameters.get("action")
        file_path_str = parameters.get("file_path")
        content = parameters.get("content", "")

        if not action:
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error="Action parameter is required",
            )

        if not file_path_str:
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error="File path parameter is required",
            )

        if self.working_directory and self._can_use_sandbox():
            return await self._execute_sandbox_edit(parameters)

        return await self._execute_direct(parameters)

    async def _execute_direct(self, parameters: Dict[str, Any]) -> ToolResult:
        """Execute the edit operation directly in the configured workspace."""
        action = parameters.get("action")
        file_path_str = parameters.get("file_path")
        content = parameters.get("content", "")

        # Resolve path and verify containment.
        if self.working_directory:
            full_path, escape_error = _resolve_and_check(
                file_path_str, self.working_directory
            )
            if escape_error is not None:
                return escape_error
        else:
            full_path = Path(file_path_str)

        try:
            if action == "write":
                content, content_error = self._get_content_parameter(
                    parameters,
                    action,
                    file_path_str,
                )
                if content_error is not None:
                    return content_error
                content = self._repair_wrapped_python_source(file_path_str, content)
                existing_content = ""
                if full_path.exists():
                    existing_content = full_path.read_text(encoding="utf-8")
                python_error = self._validate_python_content(
                    file_path_str,
                    content,
                    action=action,
                )
                if python_error is not None:
                    return python_error
                replacement_error = self._validate_python_replacement(
                    file_path_str,
                    existing_content,
                    content,
                    action=action,
                )
                if replacement_error is not None:
                    return replacement_error

                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(content, encoding="utf-8")
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=f"Successfully wrote {len(content)} characters to {file_path_str}",
                    error="",
                )

            elif action == "read":
                if not full_path.exists():
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=f"File not found: {file_path_str}",
                    )
                content = full_path.read_text(encoding="utf-8")
                line_number = parameters.get("line_number")
                if line_number is not None:
                    if not isinstance(line_number, int):
                        return ToolResult(
                            status=ToolExecutionStatus.ERROR,
                            output="",
                            error="line_number must be an integer for read action",
                        )
                    if line_number < 1:
                        return ToolResult(
                            status=ToolExecutionStatus.ERROR,
                            output="",
                            error="line_number must be >= 1 for read action",
                        )

                    line_count = parameters.get("line_count", 80)
                    if not isinstance(line_count, int):
                        return ToolResult(
                            status=ToolExecutionStatus.ERROR,
                            output="",
                            error="line_count must be an integer for read action",
                        )
                    if line_count < 1:
                        return ToolResult(
                            status=ToolExecutionStatus.ERROR,
                            output="",
                            error="line_count must be >= 1 for read action",
                        )

                    lines = content.splitlines()
                    total_lines = len(lines)
                    start_index = line_number - 1
                    if start_index >= total_lines:
                        return ToolResult(
                            status=ToolExecutionStatus.ERROR,
                            output="",
                            error=(
                                f"line_number {line_number} is past end of "
                                f"{file_path_str} ({total_lines} lines)"
                            ),
                        )
                    end_index = min(start_index + line_count, total_lines)
                    numbered_lines = [
                        f"{idx + 1}: {line}"
                        for idx, line in enumerate(
                            lines[start_index:end_index],
                            start=start_index,
                        )
                    ]
                    output = (
                        f"Lines {line_number}-{end_index} of {file_path_str} "
                        f"({total_lines} total):\n"
                        + "\n".join(numbered_lines)
                    )
                    if numbered_lines:
                        output += "\n"
                    return ToolResult(
                        status=ToolExecutionStatus.SUCCESS,
                        output=output,
                        error="",
                    )
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=content,
                    error="",
                )

            elif action == "append":
                content, content_error = self._get_content_parameter(
                    parameters,
                    action,
                    file_path_str,
                )
                if content_error is not None:
                    return content_error
                content = self._repair_wrapped_python_source(file_path_str, content)

                existing_content = ""
                if full_path.exists():
                    existing_content = full_path.read_text(encoding="utf-8")
                python_error = self._validate_python_content(
                    file_path_str,
                    existing_content + content,
                    action=action,
                )
                if python_error is not None:
                    return python_error

                if not full_path.exists():
                    full_path.parent.mkdir(parents=True, exist_ok=True)
                    full_path.touch()
                with open(full_path, "a", encoding="utf-8") as f:
                    f.write(content)
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=f"Successfully appended {len(content)} characters to {file_path_str}",
                    error="",
                )

            elif action == "line_replace":
                if not full_path.exists():
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=f"File not found: {file_path_str}",
                    )

                content, content_error = self._get_content_parameter(
                    parameters,
                    action,
                    file_path_str,
                )
                if content_error is not None:
                    return content_error

                line_number = parameters.get("line_number")
                if not isinstance(line_number, int):
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="line_number parameter is required for line_replace action",
                    )
                if line_number < 1:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="line_number must be >= 1 for line_replace action",
                    )

                line_count = parameters.get("line_count", 1)
                if not isinstance(line_count, int):
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="line_count must be an integer for line_replace action",
                    )
                if line_count < 0:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="line_count must be >= 0 for line_replace action",
                    )

                current_content = full_path.read_text(encoding="utf-8")
                current_lines = current_content.splitlines()
                start_index = line_number - 1
                if start_index > len(current_lines):
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            f"line_number {line_number} is past end of "
                            f"{file_path_str} ({len(current_lines)} lines)"
                        ),
                    )
                end_index = start_index + line_count
                if end_index > len(current_lines):
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            f"line_replace range {line_number}-{line_number + line_count - 1} "
                            f"is past end of {file_path_str} ({len(current_lines)} lines)"
                        ),
                    )

                replacement_lines = content.splitlines()
                new_lines = (
                    current_lines[:start_index]
                    + replacement_lines
                    + current_lines[end_index:]
                )
                new_content = "\n".join(new_lines)
                if new_lines:
                    new_content += "\n"

                python_error = self._validate_python_content(
                    file_path_str,
                    new_content,
                    action=action,
                )
                if python_error is not None:
                    return python_error
                replacement_error = self._validate_python_replacement(
                    file_path_str,
                    current_content,
                    new_content,
                    action=action,
                )
                if replacement_error is not None:
                    return replacement_error

                full_path.write_text(new_content, encoding="utf-8")
                end_line = line_number + line_count - 1
                if line_count == 0:
                    replaced = f"inserted before line {line_number}"
                elif line_count == 1:
                    replaced = f"replaced line {line_number}"
                else:
                    replaced = f"replaced lines {line_number}-{end_line}"
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=f"Successfully {replaced} in {file_path_str}",
                    error="",
                )

            elif action == "modify":
                if not full_path.exists():
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=f"File not found: {file_path_str}",
                    )

                search_text = parameters.get("search_text")

                if not search_text:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="search_text parameter is required for modify action",
                    )

                if "replace_text" not in parameters:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            "replace_text parameter is required for modify action; "
                            "use an explicit empty string only for intentional deletion"
                        ),
                    )

                replace_text = parameters.get("replace_text")
                if not isinstance(replace_text, str):
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error="replace_text parameter must be a string for modify action",
                    )

                current_content = full_path.read_text(encoding="utf-8")
                occurrences = current_content.count(search_text)

                if occurrences == 0:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            f"old_code not found in {file_path_str}: no occurrences "
                            "of the search text. Do not retry the same search_text; "
                            "use action='line_replace' with line_number, line_count, "
                            "and content_lines after reading a narrow line range."
                        ),
                    )

                if occurrences > 1:
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            f"Ambiguous match in {file_path_str}: "
                            f"{occurrences} occurrences of search text found; "
                            "provide more context to make the match unique"
                        ),
                    )

                # Exactly one occurrence — safe to replace.
                new_content = current_content.replace(search_text, replace_text, 1)
                python_error = self._validate_python_content(
                    file_path_str,
                    new_content,
                    action=action,
                )
                if python_error is not None:
                    return python_error
                replacement_error = self._validate_python_replacement(
                    file_path_str,
                    current_content,
                    new_content,
                    action=action,
                )
                if replacement_error is not None:
                    return replacement_error

                full_path.write_text(new_content, encoding="utf-8")
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=f"Successfully replaced 1 occurrence in {file_path_str}",
                    error="",
                )

            elif action == "delete":
                if not full_path.exists():
                    return ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=f"File not found: {file_path_str}",
                    )
                full_path.unlink()
                return ToolResult(
                    status=ToolExecutionStatus.SUCCESS,
                    output=f"Successfully deleted {file_path_str}",
                    error="",
                )

            else:
                return ToolResult(
                    status=ToolExecutionStatus.ERROR,
                    output="",
                    error=(
                        f"Unknown action: {action}. "
                        "Valid actions are: read, write, append, modify, delete"
                    ),
                )

        except Exception as e:
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=f"Error executing {action} on {file_path_str}: {str(e)}",
            )

    @staticmethod
    def _normalize_content_arguments(
        parameters: Dict[str, Any],
    ) -> ToolResult | None:
        if not isinstance(parameters, dict):
            return None

        action = parameters.get("action")
        if action not in {"write", "append", "line_replace"}:
            return None

        if "content" in parameters and "content_lines" in parameters:
            return None

        if "content_lines" in parameters:
            lines, content_error = EditTool._coerce_content_lines_value(
                parameters["content_lines"],
                action=action,
            )
            if content_error is not None:
                return content_error
            parameters["content_lines"] = lines
            return None

        if "content" not in parameters:
            return None

        content = parameters["content"]
        if isinstance(content, str):
            return None

        if isinstance(content, (list, tuple)):
            lines, content_error = EditTool._coerce_content_lines_value(
                content,
                action=action,
                parameter_name="content",
            )
            if content_error is not None:
                return content_error
            parameters["content"] = EditTool._join_content_lines(lines)
            return None

        if isinstance(content, dict):
            wrapped_content = EditTool._extract_wrapped_content(content)
            if wrapped_content is None:
                return ToolResult(
                    status=ToolExecutionStatus.ERROR,
                    output="",
                    error=(
                        f"content parameter must be a string or an array of "
                        f"source lines for {action} action"
                    ),
                )
            parameters["content"] = wrapped_content

        return None

    @staticmethod
    def _get_content_parameter(
        parameters: Dict[str, Any],
        action: str,
        file_path: str,
    ) -> tuple[str, ToolResult | None]:
        has_content = "content" in parameters
        has_content_lines = "content_lines" in parameters

        if has_content and has_content_lines:
            return "", ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"Provide either content or content_lines for {action} action, "
                    "not both"
                ),
            )

        if not has_content and not has_content_lines:
            return "", ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"content parameter is required for {action} action; "
                    "alternatively provide content_lines as an array of source "
                    "lines. Use an explicit empty string only for an intentional "
                    "empty write"
                ),
            )

        if has_content:
            if not isinstance(parameters["content"], str):
                return "", ToolResult(
                    status=ToolExecutionStatus.ERROR,
                    output="",
                    error=f"content parameter must be a string for {action} action",
                )
            return EditTool._coerce_content_string(
                file_path,
                parameters["content"],
                action=action,
            )

        content_lines = parameters["content_lines"]
        lines, content_error = EditTool._coerce_content_lines_value(
            content_lines,
            action=action,
        )
        if content_error is not None:
            return "", content_error

        return EditTool._join_content_lines(lines), None

    @staticmethod
    def _coerce_content_string(
        file_path: str,
        content: str,
        *,
        action: str,
    ) -> tuple[str, ToolResult | None]:
        if Path(file_path).suffix != ".py":
            return content, None

        stripped = content.strip()
        if not stripped or stripped[0] not in "[({":
            return content, None

        try:
            parsed = ast.literal_eval(stripped)
        except (SyntaxError, ValueError):
            return content, None

        if isinstance(parsed, str):
            return parsed, None

        if isinstance(parsed, dict):
            wrapped_content = EditTool._extract_wrapped_content(parsed)
            if wrapped_content is not None:
                return wrapped_content, None

        if isinstance(parsed, (list, tuple)):
            if len(parsed) == 1 and isinstance(parsed[0], str):
                return parsed[0], None
            lines, content_error = EditTool._coerce_content_lines_value(
                parsed,
                action=action,
                parameter_name="content",
            )
            if content_error is None:
                return EditTool._join_content_lines(lines), None

        return "", ToolResult(
            status=ToolExecutionStatus.ERROR,
            output="",
            error=(
                f"Rejected {action} for Python file {file_path}: content looks "
                "like a serialized/list fragment, not raw Python source. "
                "Retry with content_lines as an array of complete source lines "
                "or provide the final Python source directly."
            ),
        )

    @staticmethod
    def _coerce_content_lines_value(
        value: Any,
        *,
        action: str,
        parameter_name: str = "content_lines",
    ) -> tuple[list[str], ToolResult | None]:
        parsed = value
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                parsed = []
            else:
                parsed = EditTool._decode_python_or_json_literal(stripped)
                if parsed is None:
                    return [], ToolResult(
                        status=ToolExecutionStatus.ERROR,
                        output="",
                        error=(
                            f"{parameter_name} parameter must be an array for "
                            f"{action} action, got string"
                        ),
                    )

        if not isinstance(parsed, (list, tuple)):
            return [], ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"{parameter_name} parameter must be an array for "
                    f"{action} action"
                ),
            )

        lines: list[str] = []
        invalid_type = EditTool._flatten_content_lines(parsed, lines)
        if invalid_type is not None:
            return [], ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"{parameter_name} parameter must contain only strings for "
                    f"{action} action; found {invalid_type}"
                ),
            )
        return lines, None

    @staticmethod
    def _flatten_content_lines(value: Any, lines: list[str]) -> str | None:
        if isinstance(value, str):
            lines.append(value)
            return None
        if isinstance(value, (list, tuple)):
            for item in value:
                invalid_type = EditTool._flatten_content_lines(item, lines)
                if invalid_type is not None:
                    return invalid_type
            return None
        return type(value).__name__

    @staticmethod
    def _join_content_lines(content_lines: list[str]) -> str:
        content = "\n".join(content_lines)
        if content_lines:
            content += "\n"
        return content

    @staticmethod
    def _decode_python_or_json_literal(raw_text: str) -> Any:
        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            pass
        try:
            return ast.literal_eval(raw_text)
        except (SyntaxError, ValueError):
            return None

    @staticmethod
    def _extract_wrapped_content(value: dict[Any, Any]) -> str | None:
        if len(value) != 1:
            return None

        key, wrapped = next(iter(value.items()))
        if key in {"content", "source", "code"} and isinstance(wrapped, str):
            return wrapped
        if key in {"content_lines", "lines"}:
            lines, content_error = EditTool._coerce_content_lines_value(
                wrapped,
                action="write",
                parameter_name=str(key),
            )
            if content_error is None:
                return EditTool._join_content_lines(lines)
        return None

    @staticmethod
    def _validate_python_replacement(
        file_path: str,
        current_content: str,
        replacement_content: str,
        *,
        action: str,
    ) -> ToolResult | None:
        """Reject obvious partial replacements of existing Python modules."""
        if Path(file_path).suffix != ".py":
            return None
        if not current_content.strip():
            return None

        current_stripped = current_content.strip()
        replacement_stripped = replacement_content.strip()

        if (
            len(current_stripped) >= 500
            and len(replacement_stripped) < 200
            and len(replacement_stripped) < len(current_stripped) * 0.25
        ):
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"Rejected {action} for Python file {file_path}: replacement "
                    "would overwrite a substantial existing module with a tiny "
                    "fragment. Modify the specific section instead, or write the "
                    "complete replacement module."
                ),
            )

        if EditTool._defines_agent_class(
            current_content
        ) and not EditTool._defines_agent_class(replacement_content):
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"Rejected {action} for Python file {file_path}: existing "
                    "module defines an Agent class but the replacement does not. "
                    "Preserve the Agent class when self-modifying the agent."
                ),
            )

        return None

    @staticmethod
    def _validate_python_content(
        file_path: str,
        content: str,
        *,
        action: str,
    ) -> ToolResult | None:
        """Reject malformed Python writes before they poison agent workspaces."""
        if Path(file_path).suffix != ".py":
            return None

        stripped = content.strip()
        if not stripped:
            return None

        try:
            tree = ast.parse(content, filename=file_path)
        except SyntaxError as exc:
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"Rejected {action} for Python file {file_path}: content has "
                    f"a syntax error at line {exc.lineno}, column {exc.offset}: "
                    f"{exc.msg}. Write complete, valid Python source."
                ),
            )

        if EditTool._looks_like_serialized_python_fragment(stripped, tree):
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output="",
                error=(
                    f"Rejected {action} for Python file {file_path}: content looks "
                    "like a serialized/list fragment, not raw Python source. "
                    "Write the complete Python file text directly, starting with "
                    "imports, definitions, assignments, or executable statements. "
                    "If escaped multiline strings are being mangled, retry with "
                    "content_lines as an array of complete source lines, or provide "
                    "the final solution in a markdown python code block followed by "
                    "Task complete."
                ),
            )

        return None

    @staticmethod
    def _repair_wrapped_python_source(file_path: str, content: str) -> str:
        """Unwrap unambiguous provider wrappers around complete Python source."""
        if Path(file_path).suffix != ".py":
            return content

        stripped = content.strip()
        if not stripped or stripped[0] not in "[({":
            return content

        try:
            wrapped = ast.literal_eval(stripped)
        except (SyntaxError, ValueError):
            return content

        candidate = None
        if (
            isinstance(wrapped, (list, tuple))
            and len(wrapped) == 1
            and isinstance(wrapped[0], str)
        ):
            candidate = wrapped[0]
        elif isinstance(wrapped, dict) and len(wrapped) == 1:
            key, value = next(iter(wrapped.items()))
            if key in {"content", "source", "code"} and isinstance(value, str):
                candidate = value

        if candidate is None or not candidate.strip():
            return content

        try:
            tree = ast.parse(candidate, filename=file_path)
        except SyntaxError:
            return content

        if EditTool._looks_like_serialized_python_fragment(candidate.strip(), tree):
            return content

        return candidate

    @staticmethod
    def _looks_like_serialized_python_fragment(
        stripped_content: str,
        tree: ast.Module,
    ) -> bool:
        """Detect provider/tool-call fragments like ``['partial code']``."""
        if not stripped_content:
            return False
        if len(tree.body) != 1:
            return False

        first_statement = tree.body[0]
        if not isinstance(first_statement, ast.Expr):
            return False

        if isinstance(first_statement.value, (ast.List, ast.Tuple, ast.Set, ast.Dict)):
            return True

        return False

    @staticmethod
    def _defines_agent_class(content: str) -> bool:
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return False

        return any(
            isinstance(node, ast.ClassDef) and "Agent" in node.name
            for node in ast.walk(tree)
        )

    async def _execute_sandbox_edit(self, parameters: Dict[str, Any]) -> ToolResult:
        """Execute the edit operation inside the configured Docker sandbox."""
        started_at = time.time()
        sandbox_temp_parent = Path.home() / ".cache" / "dgm-sandbox"
        sandbox_temp_parent.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory(dir=str(sandbox_temp_parent)) as temp_dir:
            temp_path = Path(temp_dir)
            staged_workspace = temp_path / "workspace"
            agent_code_dir = temp_path / "agent_code"
            tool_code_dir = agent_code_dir / "agent" / "tools"
            tool_code_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(Path(__file__), tool_code_dir / "edit_tool.py")
            shutil.copy2(
                Path(__file__).with_name("base_tool.py"),
                tool_code_dir / "base_tool.py",
            )
            self._copy_workspace(
                source=Path(self.working_directory),
                destination=staged_workspace,
            )

            params_path = staged_workspace / ".dgm_edit_tool_params.json"
            params_path.write_text(json.dumps(parameters), encoding="utf-8")

            sandbox_result = await self.sandbox_manager.execute_in_sandbox(
                command=(
                    f"python3 -c {shlex.quote(_EDIT_TOOL_RUNNER)} "
                    ".dgm_edit_tool_params.json"
                ),
                agent_code_path=str(agent_code_dir),
                workspace_path=str(staged_workspace),
                timeout=self.default_timeout,
            )

            try:
                params_path.unlink(missing_ok=True)
            except TypeError:  # pragma: no cover - Python < 3.8
                if params_path.exists():
                    params_path.unlink()

            if not sandbox_result.success:
                timed_out = (
                    sandbox_result.exit_code is None
                    and "timed out" in (sandbox_result.error or "").lower()
                )
                return ToolResult(
                    status=(
                        ToolExecutionStatus.TIMEOUT
                        if timed_out
                        else ToolExecutionStatus.ERROR
                    ),
                    output=sandbox_result.output,
                    error=sandbox_result.error,
                    metadata={
                        "exit_code": sandbox_result.exit_code,
                        "sandboxed": True,
                    },
                    execution_time=(
                        sandbox_result.execution_time or time.time() - started_at
                    ),
                )

            parsed_result = self._parse_sandbox_result(sandbox_result.output)
            parsed_result.metadata = {
                **(parsed_result.metadata or {}),
                "exit_code": sandbox_result.exit_code,
                "sandboxed": True,
            }
            parsed_result.execution_time = (
                sandbox_result.execution_time or time.time() - started_at
            )

            self._copy_workspace(
                source=staged_workspace,
                destination=Path(self.working_directory),
            )
            self._apply_successful_delete_to_host(parameters, parsed_result)
            return parsed_result

    @staticmethod
    def _parse_sandbox_result(output: str) -> ToolResult:
        """Parse the JSON result emitted by the sandbox edit runner."""
        try:
            payload = json.loads(output)
            status = ToolExecutionStatus(payload.get("status", "error"))
            return ToolResult(
                status=status,
                output=payload.get("output", ""),
                error=payload.get("error", ""),
            )
        except Exception as exc:
            return ToolResult(
                status=ToolExecutionStatus.ERROR,
                output=output,
                error=f"Failed to parse sandbox edit result: {exc}",
            )

    def _apply_successful_delete_to_host(
        self,
        parameters: Dict[str, Any],
        result: ToolResult,
    ) -> None:
        """Propagate the edit tool's file delete action after workspace copy-back."""
        if result.status != ToolExecutionStatus.SUCCESS:
            return
        if parameters.get("action") != "delete":
            return
        file_path_str = parameters.get("file_path")
        if not file_path_str or not self.working_directory:
            return
        full_path, escape_error = _resolve_and_check(
            file_path_str,
            self.working_directory,
        )
        if escape_error is None and full_path.exists():
            full_path.unlink()

    @staticmethod
    def _copy_workspace(source: Path, destination: Path) -> None:
        """Copy workspace files while skipping generated Python cache files."""
        source = source.resolve()
        destination = destination.resolve()
        if not source.exists():
            destination.mkdir(parents=True, exist_ok=True)
            return

        def ignore(_dir: str, names: List[str]) -> set:
            return {
                name
                for name in names
                if name == "__pycache__" or name.endswith((".pyc", ".pyo"))
            }

        shutil.copytree(
            source,
            destination,
            dirs_exist_ok=True,
            ignore=ignore,
        )


# TODO: Implement full Edit tool functionality
# 
# Future implementation notes:
# - Implement safe file reading with size limits
# - Add file writing with backup creation
# - Support line-based editing operations
# - Add search and replace functionality
# - Implement syntax validation for code files
# - Add diff generation for modifications
# - Support multiple file operations in one call
# 
# Example structure for future implementation:
# ```python
# async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
#     action = parameters["action"]
#     file_path = parameters["file_path"]
#     
#     if action == "read":
#         return await self._read_file(file_path)
#     elif action == "write":
#         content = parameters["content"]
#         return await self._write_file(file_path, content)
#     elif action == "append":
#         content = parameters["content"]
#         return await self._append_file(file_path, content)
#     elif action == "modify":
#         return await self._modify_file(file_path, parameters)
#     else:
#         return ToolResult(
#             status=ToolExecutionStatus.INVALID_PARAMS,
#             output="",
#             error=f"Unknown action: {action}"
#         )
